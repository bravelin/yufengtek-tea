# yufengtek-delivery

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

sftp://39.108.98.48
webfront       yfzn@123
/usr/local/src/tomcat-teabigdata/webapps/ROOT   ---https
/usr/local/src/tomcat-teabigdata/webapps/yfbigdata ----http
